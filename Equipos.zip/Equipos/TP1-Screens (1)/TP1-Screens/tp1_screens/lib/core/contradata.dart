// ignore_for_file: unused_import
//
import 'package:tp1_screens/entities/contra.dart';

final usuariolist = <Usuario>[
  Usuario(
    id: '0',
    nombre: 'Messi',
    contra: '123',
  ),
   Usuario(
    id: '1',
    nombre: 'CR100T',
    contra: 'CRSEN()UNCLE',
  ),  
  Usuario(
    id: '2',
    nombre: 'Adbrepo',
    contra: 'Github.com',
  ),
   Usuario(
    id: '3',
    nombre: 'Elmasperron',
    contra: 'Giani',
  ),
  
   Usuario(
    id: '4',
    nombre: '2014',
    contra: 'Siklon',
  ),
  
   Usuario(
    id: '5',
    nombre: 'Franquitooo',
    contra: 'Celiak',
  ),
  
   Usuario(
    id: '6',
    nombre: '2004',
    contra: 'Antetokounmpo',
  ),
    Usuario(
    id: '7',
    nombre: 'Dodi',
    contra: 'Osu',
  ),
      Usuario(
    id: '8',
    nombre: '´Novena',
    contra: 'PikaFranco',
  ),
       Usuario(
    id: '9',
    nombre: 'HijodeLamineYamal',
    contra: 'SoyRabiot',
  ),
         Usuario(
    id: '10',
    nombre: 'ColePalmer',
    contra: 'Comecarne',
  ),
         Usuario(
    id: '11',
    nombre: 'Congeladoo',
    contra: 'ComeHelado',
  ),
         Usuario(
    id: '12',
    nombre: 'Cobra',
    contra: 'Boeeeeee',
  ),
         Usuario(
    id: '13',
    nombre: 'Elacabado',
    contra: 'Elquelocritica',
  ),
         Usuario(
    id: '14',
    nombre: 'OKcupid',
    contra: 'DipucKO',
  ),
         Usuario(
    id: '15',
    nombre: 'cOnTrAsEñA',
    contra: 'UsUaRiO',
  ),
];