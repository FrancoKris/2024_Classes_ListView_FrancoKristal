class Usuario {
  final String id;
  final String nombre;
  final String contra;
//
  Usuario({
     required this.id,
    required this.nombre,
    required this.contra,
  
  });
}