package com.example.tp1_screens

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
